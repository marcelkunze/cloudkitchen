/*******************************************************************************
 * Copyright (c) 2006-2009, Cloudsmith Inc.
 * The code, documentation and other materials contained herein have been
 * licensed under the Eclipse Public License - v 1.0 by the copyright holder
 * listed above, as the Initial Contributor under such license. The text or
 * such license is available at www.eclipse.org.
 ******************************************************************************/

package org.eclipse.equinox.internal.p2.repository;

/**
 * TODO: Placeholder class - should have link to p2 tracing for repository debug
 *
 */
public class RepositoryTracing {

	public static void debug(String string, Object arg) {
		// TODO Fix logging if debug is turned on
		// NLS.bind(string, new Object[] {arg});
	}

}
