/*******************************************************************************
 * Copyright (c) 2006, 2009 Cloudsmith Inc.
 *  All rights reserved. This program and the accompanying materials
 *  are made available under the terms of the Eclipse Public License v1.0
 *  which accompanies this distribution, and is available at
 *  http://www.eclipse.org/legal/epl-v10.html
 * 
 *  Contributors:
 * 	Cloudsmith Inc - initial API and implementation
 * 	IBM Corporation - ongoing development
 ******************************************************************************/
package org.eclipse.equinox.internal.p2.repository;

import java.io.*;
import java.net.*;
import org.eclipse.core.runtime.*;
import org.eclipse.equinox.internal.p2.core.helpers.LogHelper;
import org.eclipse.osgi.util.NLS;

/**
 * FileReader is responsible for retrieving files from remote and local locations.
 */
public final class FileReader {

	private Exception exception;
	protected IProgressMonitor theMonitor;
	private final int connectionRetryCount;
	private final long connectionRetryDelay;
	private boolean monitorStarted;
	private IStatus status;

	/**
	 * Create a new FileReader.
	 */
	public FileReader() {
		connectionRetryCount = RepositoryPreferences.getConnectionRetryCount();
		connectionRetryDelay = RepositoryPreferences.getConnectionMsRetryDelay();
	}

	public InputStream read(URI url, final IProgressMonitor monitor) throws CoreException, FileNotFoundException {
		final PipedInputStream input = new PipedInputStream();
		PipedOutputStream output;
		try {
			output = new PipedOutputStream(input);
		} catch (IOException e) {
			throw RepositoryStatusHelper.wrap(e);
		}
		RepositoryTracing.debug("Downloading {0}", url); //$NON-NLS-1$

		sendRetrieveRequest(url, output, true, monitor);

		return new InputStream() {
			public int available() throws IOException {
				checkException();
				int i = input.available();
				checkException();
				return i;
			}

			public void close() throws IOException {
				hardClose(input);
				checkException();
			}

			public void mark(int readlimit) {
				input.mark(readlimit);
			}

			public boolean markSupported() {
				return input.markSupported();
			}

			public int read() throws IOException {
				checkException();
				int i = input.read();
				checkException();
				return i;
			}

			public int read(byte b[]) throws IOException {
				checkException();
				int i = input.read(b);
				checkException();
				return i;
			}

			public int read(byte b[], int off, int len) throws IOException {
				checkException();
				int i = input.read(b, off, len);
				checkException();
				return i;
			}

			public void reset() throws IOException {
				checkException();
				input.reset();
				checkException();
			}

			public long skip(long n) throws IOException {
				checkException();
				long skipped = input.skip(n);
				checkException();
				return skipped;
			}

			private void checkException() throws IOException {
				Exception ex = getException();
				if (ex == null)
					return;

				IOException e;
				Throwable t = RepositoryStatusHelper.unwind(ex);
				if (t instanceof IOException)
					e = (IOException) t;
				else {
					e = new IOException(t.getMessage());
					e.initCause(t);
				}
				throw e;
			}
		};
	}

	public void readInto(URI uri, OutputStream anOutputStream, IProgressMonitor monitor) //
			throws CoreException, FileNotFoundException, AuthenticationFailedException, JREHttpClientRequiredException {
		readInto(uri, anOutputStream, -1, monitor);
	}

	public boolean belongsTo(Object family) {
		return family == this;
	}

	public void readInto(URI uri, OutputStream anOutputStream, long startPos, IProgressMonitor monitor) //
			throws CoreException, FileNotFoundException, AuthenticationFailedException {
		if (monitor == null)
			monitor = new NullProgressMonitor();
		try {
			read(uri, anOutputStream, false, monitor);
		} finally {
			// If monitor was never started, make sure it is balanced
			if (!monitorStarted)
				monitor.beginTask(null, 1);
			monitorStarted = false;
			monitor.done();
		}
	}

	protected void sendRetrieveRequest(final URI uri, final OutputStream outputStream, //
			final boolean closeStreamOnFinish, final IProgressMonitor monitor) {

		Thread downloader = new Thread(new Runnable() {
			public void run() {
				try {
					read(uri, outputStream, closeStreamOnFinish, monitor);
				} catch (Exception e) {
					// Do nothing, the exception was already assigned to FileReader.this.exception
					// and should be handled by other threads
				}
			}
		});
		downloader.start();
	}

	protected void read(URI uri, OutputStream outputStream, boolean closeStreamOnFinish, //
			IProgressMonitor monitor) throws CoreException, FileNotFoundException, AuthenticationFailedException {

		this.exception = null;
		this.theMonitor = monitor;
		this.monitorStarted = false;

		for (int retryCount = 0;; retryCount++) {
			if (monitor != null && monitor.isCanceled())
				throw new OperationCanceledException();

			BufferedInputStream bis = null;
			final int buffSize = 256 * 1024;
			try {
				bis = new BufferedInputStream(uri.toURL().openStream()
				//new FileInputStream(new File(uri))
						, buffSize);
				byte[] buffer = new byte[buffSize];
				int read;

				while ((read = bis.read(buffer, 0, buffer.length)) != -1) {
					outputStream.write(buffer, 0, read);
				}
				outputStream.flush();
				status = Status.OK_STATUS;
			} catch (FileNotFoundException e) {
				exception = e;
			} catch (IOException ioe) {
				exception = ioe;
			} finally {
				if (closeStreamOnFinish && outputStream != null) {
					hardClose(outputStream);
				}
				hardClose(bis);
			}
			if (checkException(uri, retryCount))
				break;
		}
	}

	/**
	 * Utility method to check exception condition and determine if retry should be done.
	 * If there was an exception it is translated into one of the specified exceptions and thrown.
	 * 
	 * @param uri the URI being read - used for logging purposes
	 * @param attemptCounter - the current attempt number (start with 0)
	 * @return true if the exception is an IOException and attemptCounter < connectionRetryCount, false otherwise
	 * @throws CoreException
	 * @throws FileNotFoundException
	 */
	private boolean checkException(URI uri, int attemptCounter) throws CoreException, FileNotFoundException, AuthenticationFailedException {
		// note that 'exception' could have been captured in a callback
		if (exception != null) {
			// if this is an 'authentication failure' - it is not meaningful to continue
			RepositoryStatusHelper.checkPermissionDenied(exception);

			// if this is a 'file not found' - it is not meaningful to continue
			RepositoryStatusHelper.checkFileNotFound(exception, uri);

			Throwable t = RepositoryStatusHelper.unwind(exception);
			if (t instanceof CoreException)
				throw RepositoryStatusHelper.unwindCoreException((CoreException) t);

			if (t instanceof MalformedURLException)
				throw RepositoryStatusHelper.wrap(t);

			// not meaningful to try 'timeout again' - if a server is that busy, we
			// need to wait for quite some time before retrying- it is not likely it is
			// just a temporary network thing.
			if (t instanceof SocketTimeoutException)
				throw RepositoryStatusHelper.wrap(t);

			if (t instanceof IOException && attemptCounter < connectionRetryCount) {
				// TODO: Retry only certain exceptions or filter out
				// some exceptions not worth retrying
				//
				exception = null;
				try {
					LogHelper.log(new Status(IStatus.WARNING, Activator.ID, NLS.bind(Messages.connection_to_0_failed_on_1_retry_attempt_2, new String[] {uri.toString(), t.getMessage(), String.valueOf(attemptCounter)}), t));

					Thread.sleep(connectionRetryDelay);
					return false;
				} catch (InterruptedException e) {
					/* ignore */
				}
			}
			throw RepositoryStatusHelper.wrap(exception);
		}
		return true;
	}

	protected Exception getException() {
		return exception;
	}

	/**
	 * Closes input and output streams
	 * @param aStream
	 */
	public static void hardClose(Object aStream) {
		if (aStream != null) {
			try {
				if (aStream instanceof OutputStream)
					((OutputStream) aStream).close();
				else if (aStream instanceof InputStream)
					((InputStream) aStream).close();
			} catch (IOException e) { /* ignore */
			}
		}
	}

	public IStatus getResult() {
		return status;
	}

}
