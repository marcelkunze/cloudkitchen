/*******************************************************************************
 *  Copyright (c) 2008, 2010 IBM Corporation and others.
 *  All rights reserved. This program and the accompanying materials
 *  are made available under the terms of the Eclipse Public License v1.0
 *  which accompanies this distribution, and is available at
 *  http://www.eclipse.org/legal/epl-v10.html
 * 
 *  Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.equinox.internal.p2.touchpoint.eclipse.actions;

import java.util.Map;
import org.eclipse.core.runtime.*;
import org.eclipse.equinox.internal.p2.touchpoint.eclipse.TouchpointActivator;
import org.eclipse.equinox.internal.provisional.p2.repository.RepositoryEvent;
import org.eclipse.equinox.p2.core.IAgentLocation;
import org.eclipse.equinox.p2.core.IProvisioningAgent;
import org.eclipse.equinox.p2.engine.IProfile;
import org.eclipse.equinox.p2.engine.IProfileRegistry;
import org.eclipse.equinox.p2.engine.spi.ProvisioningAction;

/**
 * An action that adds a repository to the list of known repositories.
 */
public class AddRepositoryAction extends ProvisioningAction {
	public static final String ID = "addRepository"; //$NON-NLS-1$
	public static final String NOT_SUPPORTED_MESSAGE = "Add/RemoveRepositoryActions are not supported and are ignored";

	public AddRepositoryAction() {
		this.actionID = ID;
	}
	
	public IStatus execute(Map<String, Object> parameters) {		
		return new Status(IStatus.WARNING, TouchpointActivator.ID, NOT_SUPPORTED_MESSAGE);
		
	}

	protected String getId() {
		return ID;
	}

	public IStatus undo(Map<String, Object> parameters) {			
		return Status.OK_STATUS;
	
	}
}
