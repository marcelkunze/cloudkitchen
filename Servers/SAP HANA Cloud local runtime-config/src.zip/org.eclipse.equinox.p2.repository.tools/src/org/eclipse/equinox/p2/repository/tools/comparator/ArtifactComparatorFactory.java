/*******************************************************************************
 *  Copyright (c) 2008, 2010 IBM Corporation and others.
 *  All rights reserved. This program and the accompanying materials
 *  are made available under the terms of the Eclipse Public License v1.0
 *  which accompanies this distribution, and is available at
 *  http://www.eclipse.org/legal/epl-v10.html
 * 
 *  Contributors:
 *     IBM Corporation - initial API and implementation
 *		Compeople AG (Stefan Liebig) - various ongoing maintenance
 *******************************************************************************/
package org.eclipse.equinox.p2.repository.tools.comparator;

import org.eclipse.equinox.internal.p2.artifact.repository.Messages;
import org.eclipse.equinox.p2.internal.repository.comparator.JarComparator;
import org.eclipse.equinox.p2.internal.repository.comparator.MD5ArtifactComparator;
import org.eclipse.osgi.util.NLS;

/**
 * @since 2.0
 */
public class ArtifactComparatorFactory {

	private static MD5ArtifactComparator md5Comparator = null;
	private static JarComparator jarComparator = null;

	public static synchronized IArtifactComparator getArtifactComparator(String comparatorID) {
		if (comparatorID == null || MD5ArtifactComparator.MD5_COMPARATOR_ID.equals(comparatorID)) {
			if (md5Comparator == null) {
				md5Comparator = new MD5ArtifactComparator();
			}
			return md5Comparator;
		} else if ("org.eclipse.equinox.p2.repository.tools.jar.comparator".equals(comparatorID)) { //$NON-NLS-1$
			if (jarComparator == null) {
				jarComparator = new JarComparator();
			}
			return jarComparator;
		}

		throw new IllegalArgumentException(NLS.bind(Messages.exception_comparatorNotFound, comparatorID));
	}
}
